<?php

declare(strict_types=1);

namespace Volt\Payment\Exception;

use Magento\Payment\Gateway\Http\ClientException;

class NotificationException extends ClientException
{

}
