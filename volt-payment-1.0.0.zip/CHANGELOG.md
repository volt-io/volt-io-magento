# What changed in Volt: Pay by Bank Module?

## 1.0.0
* First release for Magento 2.3 and 2.4
