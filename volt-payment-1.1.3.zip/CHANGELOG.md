# What changed in Volt: Pay by Bank Module?

## 1.1.1
* Fixes for CRON and ABANDONED_BY_USER statuses.
* Make inputs for credientals in the configuration obscure (showing *** instead of plain text).

## 1.1.0
* Change API structure.
* Add rest of Volt statuses to module.

## 1.0.0
* First release for Magento 2.3 and 2.4
