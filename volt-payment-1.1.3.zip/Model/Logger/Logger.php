<?php

declare(strict_types=1);

namespace Volt\Payment\Model\Logger;

use Monolog\Logger as MonologLogger;

class Logger extends MonologLogger
{

}
